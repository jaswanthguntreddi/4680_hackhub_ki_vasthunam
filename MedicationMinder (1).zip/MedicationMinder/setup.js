#!/usr/bin/env node

const fs = require('fs');
const { execSync } = require('child_process');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

async function setup() {
  console.log('🔧 Setting up MedTracker development environment...');

  // Check Node.js version
  const nodeVersion = process.version;
  console.log(`\nNode.js version: ${nodeVersion}`);
  if (parseInt(nodeVersion.slice(1)) < 20) {
    console.error('⚠️  Warning: This project requires Node.js v20 or later');
  }

  // Create .env file if it doesn't exist
  if (!fs.existsSync('.env')) {
    const envContent = `TWILIO_PHONE_NUMBER=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
SESSION_SECRET=${require('crypto').randomBytes(64).toString('hex')}
`;
    fs.writeFileSync('.env', envContent);
    console.log('✅ Created .env file with template values');
  }

  // Install dependencies
  console.log('\n📦 Installing dependencies...');
  execSync('npm install', { stdio: 'inherit' });

  console.log('\n✅ Setup complete! You can now run:');
  console.log('npm run dev');
}

setup().catch(console.error);
