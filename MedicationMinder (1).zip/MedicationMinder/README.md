# MedTracker - Medication Management System

## Project Setup Guide

### Prerequisites
- Node.js (v20 or later)
- npm (latest version)
- VS Code

### Project Structure
```
├── client/
│   └── src/
│       ├── components/
│       ├── hooks/
│       ├── lib/
│       ├── pages/
│       └── App.tsx
├── server/
│   ├── auth.ts
│   ├── notifications.ts
│   ├── routes.ts
│   └── storage.ts
└── shared/
    └── schema.ts
```

### Installation Steps

1. Clone the project files to your local machine

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file in the root directory with these variables:
```env
TWILIO_PHONE_NUMBER=your_twilio_phone_number
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
SESSION_SECRET=your_session_secret
```

4. Set up your development environment:
```bash
# Install required VS Code extensions
- ESLint
- Prettier
- Tailwind CSS IntelliSense
```

### Running the Application

1. Start the development server:
```bash
npm run dev
```

2. The application will be available at:
- Frontend: http://localhost:5000
- Backend API: http://localhost:5000/api

### Features
- User Authentication (Login/Register)
- Medication Management
- SMS Reminders (requires Twilio setup)
- Adherence Tracking
- Medication History Calendar

### Tech Stack
- Frontend: React + TypeScript
- Backend: Express.js
- State Management: TanStack Query
- UI Components: shadcn/ui
- Styling: Tailwind CSS
- Authentication: Passport.js
- Notifications: Twilio

### Important Notes
1. Make sure to have a Twilio account set up for SMS notifications
2. For development, you can use memory storage (default) or set up a PostgreSQL database
3. The session secret should be a secure random string
