import { HfInference } from '@huggingface/inference';

const hf = new HfInference();

const SYSTEM_PROMPT = `You are a helpful medication management assistant. You can:
1. Answer questions about medications and their general usage
2. Provide reminders about medication adherence
3. Explain common side effects and interactions
4. Give general health advice

You cannot:
1. Provide medical diagnosis
2. Prescribe medications
3. Replace professional medical advice

Always remind users to consult healthcare professionals for specific medical advice.`;

export async function getChatbotResponse(userMessage: string): Promise<string> {
  try {
    // Using a free model from HuggingFace for chat responses
    const response = await hf.textGeneration({
      model: 'facebook/blenderbot-400M-distill',
      inputs: `${SYSTEM_PROMPT}\n\nUser: ${userMessage}\nAssistant:`,
      parameters: {
        max_new_tokens: 150,
        temperature: 0.7,
        top_p: 0.9,
        repetition_penalty: 1.2
      }
    });

    return response.generated_text || findFallbackResponse(userMessage);
  } catch (error) {
    console.error("Chatbot error:", error);
    return findFallbackResponse(userMessage);
  }
}

// Image captioning function using HuggingFace's free model
export async function generateImageCaption(imageData: string): Promise<string> {
  try {
    const response = await hf.imageToText({
      model: "Salesforce/blip-image-captioning-base",
      data: imageData
    });
    return response.text;
  } catch (error) {
    console.error("Image captioning error:", error);
    return "I'm sorry, I couldn't analyze the image. Could you please describe what you're showing me?";
  }
}

// Fallback response system for when the API is unavailable
function findFallbackResponse(input: string): string {
  const lowercaseInput = input.toLowerCase();

  // Basic pattern matching for common queries
  if (lowercaseInput.includes('hello') || lowercaseInput.includes('hi')) {
    return "Hello! I'm your medication assistant. How can I help you today?";
  }

  if (lowercaseInput.includes('reminder') || lowercaseInput.includes('schedule')) {
    return "I can help you set up medication reminders. Would you like to know how?";
  }

  if (lowercaseInput.includes('side effect')) {
    return "If you're experiencing side effects, it's important to consult your healthcare provider.";
  }

  if (lowercaseInput.includes('adherence') || lowercaseInput.includes('missed')) {
    return "Regular medication adherence is important for your health. Would you like to check your adherence history?";
  }

  // Default response
  return "I can help you with medication reminders, adherence tracking, and general medication information. What would you like to know?";
}