import { HfInference } from '@huggingface/inference';

const hf = new HfInference();

export async function generateImageCaption(imageData: string): Promise<string> {
  try {
    const response = await hf.imageToText({
      model: "Salesforce/blip-image-captioning-base",
      data: imageData
    });
    return response.text || "Could not generate caption for this image.";
  } catch (error) {
    console.error("Image processing error:", error);
    return "I'm sorry, I couldn't analyze the image. Could you please describe what you're showing me?";
  }
}
