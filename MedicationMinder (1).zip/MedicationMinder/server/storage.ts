import { users, medications, adherence } from "@shared/schema";
import type { User, InsertUser, Medication, InsertMedication, Adherence, InsertAdherence } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// Add EmergencyContact related types here (assuming these types are defined elsewhere)
interface EmergencyContact {
    id: number;
    userId: number;
    name: string;
    phone: string;
    relationship: string;
    isPrimaryContact: boolean;
}
interface InsertEmergencyContact {
    name: string;
    phone: string;
    relationship: string;
    isPrimaryContact: boolean;
}

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getMedications(userId: number): Promise<Medication[]>;
  getMedication(id: number): Promise<Medication | undefined>;
  createMedication(medication: InsertMedication & { userId: number }): Promise<Medication>;
  updateMedication(id: number, medication: Partial<InsertMedication>): Promise<Medication | undefined>;
  deleteMedication(id: number): Promise<boolean>;

  getAdherence(userId: number, startDate: Date, endDate: Date): Promise<Adherence[]>;
  createAdherence(adherence: InsertAdherence & { userId: number }): Promise<Adherence>;

  sessionStore: session.Store;
  getEmergencyContacts(userId: number): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact & { userId: number }): Promise<EmergencyContact>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private medications: Map<number, Medication>;
  private adherence: Map<number, Adherence>;
  private emergencyContacts: Map<number, EmergencyContact>;
  currentId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.medications = new Map();
    this.adherence = new Map();
    this.emergencyContacts = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Prune expired entries every 24h
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = {
      id,
      username: insertUser.username,
      password: insertUser.password,
      phone: insertUser.phone || null,
      email: insertUser.email || null,
      name: insertUser.name || null,
    };
    this.users.set(id, user);
    return user;
  }

  async getMedications(userId: number): Promise<Medication[]> {
    return Array.from(this.medications.values()).filter(
      (med) => med.userId === userId,
    );
  }

  async getMedication(id: number): Promise<Medication | undefined> {
    return this.medications.get(id);
  }

  async createMedication(medication: InsertMedication & { userId: number }): Promise<Medication> {
    const id = this.currentId++;
    const med: Medication = {
      id,
      name: medication.name,
      userId: medication.userId,
      dosage: medication.dosage,
      frequency: medication.frequency,
      timeOfDay: Array.isArray(medication.timeOfDay) ? medication.timeOfDay[0] : medication.timeOfDay,
      startDate: new Date(medication.startDate),
      endDate: medication.endDate ? new Date(medication.endDate) : null,
      instructions: medication.instructions || null,
    };
    this.medications.set(id, med);
    return med;
  }

  async updateMedication(id: number, medication: Partial<InsertMedication>): Promise<Medication | undefined> {
    const existing = this.medications.get(id);
    if (!existing) return undefined;

    const updated = { ...existing };
    if (medication.name) updated.name = medication.name;
    if (medication.dosage) updated.dosage = medication.dosage;
    if (medication.frequency) updated.frequency = medication.frequency;
    if (medication.timeOfDay) updated.timeOfDay = Array.isArray(medication.timeOfDay) ? medication.timeOfDay[0] : medication.timeOfDay;
    if (medication.startDate) updated.startDate = new Date(medication.startDate);
    if (medication.endDate) updated.endDate = new Date(medication.endDate);
    if (medication.instructions !== undefined) updated.instructions = medication.instructions;

    this.medications.set(id, updated);
    return updated;
  }

  async deleteMedication(id: number): Promise<boolean> {
    try {
      const result = await db.delete(medications).where(eq(medications.id, id));
      return result.rowCount > 0;
    } catch (error) {
      console.error('Error deleting medication:', error);
      return false;
    }
  }

  async getAdherence(userId: number, startDate: Date, endDate: Date): Promise<Adherence[]> {
    return Array.from(this.adherence.values()).filter(
      (adh) => adh.userId === userId && 
               adh.scheduledTime >= startDate && 
               adh.scheduledTime <= endDate
    );
  }

  async createAdherence(adherence: InsertAdherence & { userId: number }): Promise<Adherence> {
    const id = this.currentId++;
    const adh: Adherence = {
      id,
      userId: adherence.userId,
      medicationId: adherence.medicationId,
      taken: adherence.taken,
      scheduledTime: new Date(adherence.scheduledTime),
      takenTime: adherence.takenTime ? new Date(adherence.takenTime) : null,
    };
    this.adherence.set(id, adh);
    return adh;
  }

  async getEmergencyContacts(userId: number): Promise<EmergencyContact[]> {
    return Array.from(this.emergencyContacts.values()).filter(
      (contact) => contact.userId === userId,
    );
  }

  async createEmergencyContact(contact: InsertEmergencyContact & { userId: number }): Promise<EmergencyContact> {
    const id = this.currentId++;
    const newContact: EmergencyContact = {
      id,
      userId: contact.userId,
      name: contact.name,
      phone: contact.phone,
      relationship: contact.relationship,
      isPrimaryContact: contact.isPrimaryContact,
    };
    this.emergencyContacts.set(id, newContact);
    return newContact;
  }
}

export const storage = new MemStorage();