import twilio from 'twilio';
import { Medication } from '@shared/schema';
import { format, parseISO } from 'date-fns';

// Check if all required Twilio credentials are present
const twilioCredentials = {
  accountSid: process.env.TWILIO_ACCOUNT_SID,
  authToken: process.env.TWILIO_AUTH_TOKEN,
  phoneNumber: process.env.TWILIO_PHONE_NUMBER
};

// Validate Twilio configuration
Object.entries(twilioCredentials).forEach(([key, value]) => {
  if (!value) {
    throw new Error(`Missing Twilio credential: ${key}`);
  }
});

const client = twilio(twilioCredentials.accountSid, twilioCredentials.authToken);

export async function sendSMS(to: string, message: string): Promise<boolean> {
  try {
    // Validate recipient phone number format
    if (!to.match(/^\+[1-9]\d{1,14}$/)) {
      console.error('Invalid recipient phone number format:', to);
      return false;
    }

    // Ensure Twilio phone number is in E.164 format
    let fromNumber = twilioCredentials.phoneNumber;
    if (!fromNumber.startsWith('+')) {
      fromNumber = `+${fromNumber}`;
    }

    // Log attempt for debugging
    console.log('Attempting to send SMS:', {
      to,
      from: fromNumber,
      messageLength: message.length,
      accountSid: twilioCredentials.accountSid.substring(0, 8) + '...'
    });

    const result = await client.messages.create({
      body: message,
      to: to,
      from: fromNumber,
    });

    // Log successful send
    console.log('SMS sent successfully:', {
      sid: result.sid,
      status: result.status,
      to: to,
      errorCode: result.errorCode,
      errorMessage: result.errorMessage
    });

    return true;
  } catch (error: any) {
    // Handle specific Twilio error codes
    switch (error.code) {
      case 21608: // Unverified number in trial account
        console.log('SMS failed - Unverified number in trial account:', {
          to,
          error: error.message
        });
        return false;

      case 21211: // Invalid 'To' number
        console.error('SMS failed - Invalid phone number:', {
          to,
          error: error.message
        });
        return false;

      case 21214: // 'To' number is not a mobile number
        console.error('SMS failed - Not a mobile number:', {
          to,
          error: error.message
        });
        return false;

      default:
        console.error('SMS sending error:', {
          code: error.code,
          message: error.message,
          moreInfo: error.moreInfo,
          details: error.details,
          fromNumber: twilioCredentials.phoneNumber
        });
        return false;
    }
  }
}

export async function scheduleReminder(medication: Medication, phone: string): Promise<boolean> {
  try {
    // Format the message with medication details
    const message = formatReminderMessage(medication);

    // Log scheduling attempt
    console.log('Scheduling reminder for:', {
      medicationName: medication.name,
      phone,
      messageLength: message.length,
      scheduledTime: medication.timeOfDay
    });

    // Send the reminder
    const result = await sendSMS(phone, message);
    if (!result) {
      console.error(`Failed to send reminder for medication: ${medication.name} to phone: ${phone}`);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error scheduling reminder:', error);
    return false;
  }
}

function formatReminderMessage(medication: Medication): string {
  let message = `🔔 Medication Reminder\n`;
  message += `Medicine: ${medication.name}\n`;
  message += `Dosage: ${medication.dosage}\n`;

  if (medication.instructions) {
    message += `Instructions: ${medication.instructions}\n`;
  }

  if (medication.frequency !== 'as_needed') {
    message += `Frequency: ${formatFrequency(medication.frequency)}`;
  }

  return message;
}

function formatFrequency(frequency: string): string {
  const frequencyMap: Record<string, string> = {
    'once_daily': 'Once daily',
    'twice_daily': 'Twice daily',
    'three_times_daily': 'Three times daily',
    'four_times_daily': 'Four times daily',
    'weekly': 'Weekly',
    'as_needed': 'As needed'
  };

  return frequencyMap[frequency] || frequency;
}