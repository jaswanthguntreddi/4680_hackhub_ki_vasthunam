import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { medications, adherence, insertMedicationSchema, insertAdherenceSchema } from "@shared/schema";
import { scheduleReminder } from "./notifications";
import { getChatbotResponse } from "./chatbot";
import { sendSMS } from "./sms";
import { generateImageCaption } from "./imageProcessor";
import { db } from "./db";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Middleware to check authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Add sync endpoint for local storage data
  app.post("/api/sync", requireAuth, async (req, res) => {
    try {
      const { medications: medsData, adherence: adhData } = req.body;
      const userId = req.user!.id;

      console.log('Syncing data for user:', userId, {
        medicationsCount: medsData?.length || 0,
        adherenceCount: adhData?.length || 0
      });

      // Sync medications
      if (medsData?.length) {
        for (const med of medsData) {
          try {
            const existingMeds = await db
              .select()
              .from(medications)
              .where(eq(medications.id, med.id));

            if (!existingMeds.length) {
              await db.insert(medications).values({
                userId: userId,
                name: med.name,
                dosage: med.dosage,
                frequency: med.frequency,
                timeOfDay: Array.isArray(med.timeOfDay) ? med.timeOfDay : [med.timeOfDay],
                startDate: new Date(med.startDate),
                endDate: med.endDate ? new Date(med.endDate) : null,
                instructions: med.instructions || null
              });
            }
          } catch (error) {
            console.error('Error syncing medication:', error);
          }
        }
      }

      // Sync adherence records
      if (adhData?.length) {
        for (const adh of adhData) {
          try {
            const existingAdh = await db
              .select()
              .from(adherence)
              .where(eq(adherence.id, adh.id));

            if (!existingAdh.length) {
              await db.insert(adherence).values({
                userId: userId,
                medicationId: adh.medicationId,
                taken: adh.taken,
                scheduledTime: new Date(adh.scheduledTime),
                takenTime: adh.takenTime ? new Date(adh.takenTime) : null
              });
            }
          } catch (error) {
            console.error('Error syncing adherence:', error);
          }
        }
      }

      // Fetch synced data
      const syncedMedications = await db
        .select()
        .from(medications)
        .where(eq(medications.userId, userId));

      const syncedAdherence = await db
        .select()
        .from(adherence)
        .where(eq(adherence.userId, userId));

      res.json({
        message: "Data synced successfully",
        data: {
          medications: syncedMedications,
          adherence: syncedAdherence
        }
      });
    } catch (error) {
      console.error("Error syncing data:", error);
      res.status(500).json({ error: "Failed to sync data" });
    }
  });

  // Emergency Contact routes
  app.get("/api/emergency-contacts", requireAuth, async (req, res) => {
    try {
      const contacts = await storage.getEmergencyContacts(req.user!.id);
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching emergency contacts:", error);
      res.status(500).json({ error: "Failed to fetch emergency contacts" });
    }
  });

  app.post("/api/emergency-contacts", requireAuth, async (req, res) => {
    try {
      const contact = await storage.createEmergencyContact({
        ...req.body,
        userId: req.user!.id,
      });
      res.status(201).json(contact);
    } catch (error) {
      console.error("Error creating emergency contact:", error);
      res.status(400).json({ error: "Failed to create emergency contact" });
    }
  });

  app.post("/api/sos/trigger", requireAuth, async (req, res) => {
    try {
      // Get user's emergency contacts
      const contacts = await storage.getEmergencyContacts(req.user!.id);

      // Send notifications to emergency contacts
      for (const contact of contacts) {
        if (contact.phone) {
          await sendSMS(
            contact.phone,
            `EMERGENCY ALERT: ${req.user!.name || req.user!.username} has triggered their emergency SOS. Please contact them immediately or emergency services if needed.`
          );
        }
      }

      res.json({ message: "Emergency contacts notified" });
    } catch (error) {
      console.error("Error triggering SOS:", error);
      res.status(500).json({ error: "Failed to trigger SOS" });
    }
  });

  // Medication routes
  app.get("/api/medications", requireAuth, async (req, res) => {
    const medications = await storage.getMedications(req.user!.id);
    res.json(medications);
  });

  app.post("/api/medications", requireAuth, async (req, res) => {
    try {
      const data = insertMedicationSchema.parse(req.body);
      const medication = await storage.createMedication({
        ...data,
        userId: req.user!.id,
      });

      let reminderStatus = null;
      if (req.user!.phone) {
        // Schedule reminders for each time slot
        const reminderPromises = data.timeOfDay.map(async (timeSlot: string) => {
          const reminderMedication = { ...medication, timeOfDay: timeSlot };
          return await scheduleReminder(reminderMedication, req.user!.phone);
        });

        const reminderResults = await Promise.all(reminderPromises);
        reminderStatus = reminderResults.every(success => success) ? 'sent' : 'failed';
      }

      res.status(201).json({
        medication,
        reminder: reminderStatus
      });
    } catch (error) {
      console.error("Error creating medication:", error);
      res.status(400).json({
        message: "Failed to create medication",
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.put("/api/medications/:id", requireAuth, async (req, res) => {
    const medication = await storage.getMedication(parseInt(req.params.id));
    if (!medication || medication.userId !== req.user!.id) {
      return res.status(404).json({ message: "Medication not found" });
    }

    const data = insertMedicationSchema.partial().parse(req.body);
    const updated = await storage.updateMedication(medication.id, data);
    res.json(updated);
  });

  app.delete("/api/medications/:id", requireAuth, async (req, res) => {
    try {
      // First check if the medication exists and belongs to the user
      const [medication] = await db
        .select()
        .from(medications)
        .where(eq(medications.id, parseInt(req.params.id)))
        .where(eq(medications.userId, req.user!.id));

      if (!medication) {
        return res.status(404).json({ message: "Medication not found or unauthorized" });
      }

      // Delete the medication
      const deleted = await storage.deleteMedication(medication.id);

      if (deleted) {
        res.sendStatus(204);
      } else {
        res.status(500).json({ message: "Failed to delete medication" });
      }
    } catch (error) {
      console.error("Error deleting medication:", error);
      res.status(500).json({ error: "Failed to delete medication" });
    }
  });

  // Adherence routes
  app.get("/api/adherence", requireAuth, async (req, res) => {
    const startDate = new Date(req.query.startDate as string);
    const endDate = new Date(req.query.endDate as string);

    const adherence = await storage.getAdherence(
      req.user!.id,
      startDate,
      endDate
    );
    res.json(adherence);
  });

  app.post("/api/adherence", requireAuth, async (req, res) => {
    const data = insertAdherenceSchema.parse(req.body);
    const adherence = await storage.createAdherence({
      ...data,
      userId: req.user!.id,
    });
    res.status(201).json(adherence);
  });

  app.post("/api/chat", requireAuth, async (req, res) => {
    try {
      const { message, type, data } = req.body;

      if (!message && !data) {
        return res.status(400).json({ error: "Message or data is required" });
      }

      let response;

      if (type === 'image' && data) {
        // Handle image input
        response = await generateImageCaption(data);
      } else {
        // Handle text input
        response = await getChatbotResponse(message);
      }

      res.json({ response });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ error: "Failed to get chatbot response" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}