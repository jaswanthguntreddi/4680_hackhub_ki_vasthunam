import { apiRequest } from "@/lib/queryClient";

interface StorageData {
  medications?: any[];
  adherence?: any[];
}

export async function syncLocalStorageToDb(userId: number) {
  try {
    // Get data from localStorage
    const localData: StorageData = {};
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith('med_')) {
        if (!localData.medications) localData.medications = [];
        localData.medications.push(JSON.parse(localStorage.getItem(key) || ''));
      }
      if (key.startsWith('adh_')) {
        if (!localData.adherence) localData.adherence = [];
        localData.adherence.push(JSON.parse(localStorage.getItem(key) || ''));
      }
    }

    // Send data to server for syncing
    await apiRequest("POST", "/api/sync", localData);

    // Clear localStorage after successful sync
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith('med_') || key.startsWith('adh_')) {
        localStorage.removeItem(key);
      }
    }

    // Fetch and return the synced data
    const medications = await (await apiRequest("GET", "/api/medications")).json();
    const adherenceRecords = await (await apiRequest("GET", "/api/adherence", {
      startDate: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0]
    })).json();

    return {
      success: true,
      data: {
        medications,
        adherence: adherenceRecords
      }
    };
  } catch (error) {
    console.error('Error syncing localStorage to database:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}