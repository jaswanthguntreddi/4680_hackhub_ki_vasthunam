import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, parseISO, isBefore } from "date-fns";
import { Pill, Check, Edit, Trash2, Clock, AlertCircle } from "lucide-react";
import type { Medication } from "@shared/schema";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import MedicationForm from "./medication-form";

interface MedicationListItemProps {
  medication: Medication;
  showActions?: boolean;
}

export function MedicationListItem({ medication, showActions = true }: MedicationListItemProps) {
  const { toast } = useToast();
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isTaken, setIsTaken] = useState(false);

  const markAsTakenMutation = useMutation({
    mutationFn: async () => {
      const currentTime = new Date().toISOString();
      const res = await apiRequest("POST", "/api/adherence", {
        medicationId: medication.id,
        taken: true,
        scheduledTime: Array.isArray(medication.timeOfDay) 
          ? medication.timeOfDay[0] 
          : medication.timeOfDay,
        takenTime: currentTime
      });
      return res.json();
    },
    onSuccess: () => {
      setIsTaken(true);
      queryClient.invalidateQueries({ queryKey: ["/api/adherence"] });
      toast({
        title: "Success",
        description: "Medication marked as taken",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMedicationMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/medications/${medication.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medications"] });
      toast({
        title: "Success",
        description: "Medication deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const canTakeMedication = () => {
    const now = new Date();
    const scheduledTime = Array.isArray(medication.timeOfDay)
      ? new Date(medication.timeOfDay[0])
      : new Date(medication.timeOfDay);
    const thirtyMinutesBefore = new Date(scheduledTime.getTime() - 30 * 60000);
    return isBefore(thirtyMinutesBefore, now);
  };

  const handleDelete = () => {
    if (window.confirm("Are you sure you want to delete this medication?")) {
      deleteMedicationMutation.mutate();
    }
  };

  const formatTimeOfDay = (timeOfDay: Date[] | null): string => {
    if (!timeOfDay) return "No time set";
    if (Array.isArray(timeOfDay)) {
      return timeOfDay.map(time => format(new Date(time), "h:mm a")).join(", ");
    }
    return format(new Date(timeOfDay), "h:mm a");
  };

  return (
    <>
      <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/5 transition-all group">
        <div className="flex items-center gap-4">
          <div className={`h-12 w-12 rounded-full flex items-center justify-center transition-colors ${
            isTaken ? 'bg-green-100 text-green-600' : 'bg-primary/10 text-primary'
          }`}>
            <Pill className="h-6 w-6" />
          </div>
          <div className="space-y-1">
            <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
              {medication.name}
            </h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>{medication.dosage}</span>
              <span>•</span>
              <span>{medication.frequency}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>{formatTimeOfDay(medication.timeOfDay)}</span>
            </div>
            {medication.instructions && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <AlertCircle className="h-4 w-4" />
                <span>{medication.instructions}</span>
              </div>
            )}
          </div>
        </div>
        {showActions && (
          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button 
              variant={isTaken ? "default" : "outline"}
              size="sm"
              onClick={() => markAsTakenMutation.mutate()}
              disabled={markAsTakenMutation.isPending || !canTakeMedication() || isTaken}
              className={`transition-colors ${isTaken ? "bg-green-600 hover:bg-green-700" : ""}`}
            >
              {markAsTakenMutation.isPending ? (
                <>
                  <Check className="mr-2 h-4 w-4 animate-spin" />
                  Marking...
                </>
              ) : isTaken ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Done
                </>
              ) : (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Mark as Taken
                </>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsEditDialogOpen(true)}
              className="hover:text-primary"
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleDelete}
              className="text-destructive hover:bg-destructive/10"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-5 w-5" />
              Edit Medication
            </DialogTitle>
          </DialogHeader>
          <MedicationForm 
            medication={medication} 
            onSuccess={() => {
              setIsEditDialogOpen(false);
              queryClient.invalidateQueries({ queryKey: ["/api/medications"] });
            }} 
          />
        </DialogContent>
      </Dialog>
    </>
  );
}