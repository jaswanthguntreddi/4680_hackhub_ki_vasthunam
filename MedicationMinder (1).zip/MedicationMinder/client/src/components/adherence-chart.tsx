import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, Legend } from "recharts";
import { useQuery } from "@tanstack/react-query";
import { format, subDays } from "date-fns";
import type { Adherence, Medication } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

export default function AdherenceChart() {
  const { data: adherence = [], isLoading: isLoadingAdherence } = useQuery<Adherence[]>({
    queryKey: ["/api/adherence", {
      startDate: format(subDays(new Date(), 30), 'yyyy-MM-dd'),
      endDate: format(new Date(), 'yyyy-MM-dd')
    }]
  });

  const { data: medications = [], isLoading: isLoadingMeds } = useQuery<Medication[]>({
    queryKey: ["/api/medications"]
  });

  if (isLoadingAdherence || isLoadingMeds) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  // Calculate overall adherence rate
  const adherenceRate = adherence.length > 0
    ? (adherence.filter(a => a.taken).length / adherence.length * 100).toFixed(1)
    : 0;

  // Prepare data for the line chart
  const dailyAdherenceData = Array.from({ length: 30 }, (_, i) => {
    const date = subDays(new Date(), i);
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayRecords = adherence.filter(a => 
      format(new Date(a.scheduledTime), 'yyyy-MM-dd') === dateStr
    );
    const takenCount = dayRecords.filter(r => r.taken).length;
    const totalCount = dayRecords.length;

    return {
      date: format(date, 'MMM dd'),
      adherenceRate: totalCount > 0 ? (takenCount / totalCount * 100) : 0
    };
  }).reverse();

  // Prepare data for medication-specific adherence
  const medicationAdherenceData = medications.map(med => {
    const medRecords = adherence.filter(a => a.medicationId === med.id);
    const takenCount = medRecords.filter(r => r.taken).length;
    const totalCount = medRecords.length;

    return {
      name: med.name,
      adherenceRate: totalCount > 0 ? (takenCount / totalCount * 100) : 0,
      totalDoses: totalCount,
      takenDoses: takenCount
    };
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle>Medication Adherence</CardTitle>
        <div className="text-2xl font-bold">{adherenceRate}%</div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="timeline" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="timeline">Timeline View</TabsTrigger>
            <TabsTrigger value="medication">By Medication</TabsTrigger>
          </TabsList>

          <TabsContent value="timeline">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={dailyAdherenceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="date" 
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis domain={[0, 100]} />
                  <Tooltip 
                    formatter={(value: number) => [`${value.toFixed(1)}%`, 'Adherence Rate']}
                  />
                  <Line
                    type="monotone"
                    dataKey="adherenceRate"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--primary))" }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="medication">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={medicationAdherenceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name"
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis domain={[0, 100]} />
                  <Tooltip 
                    formatter={(value: number, name: string) => [
                      `${value.toFixed(1)}%`,
                      name === 'adherenceRate' ? 'Adherence Rate' : name
                    ]}
                  />
                  <Legend />
                  <Bar
                    dataKey="adherenceRate"
                    fill="hsl(var(--primary))"
                    name="Adherence Rate"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}