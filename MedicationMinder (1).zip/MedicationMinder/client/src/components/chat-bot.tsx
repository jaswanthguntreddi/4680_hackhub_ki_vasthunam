import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

export function ChatBot() {
  return (
    <Button
      variant="outline"
      size="icon"
      className="fixed bottom-4 right-4 h-12 w-12 rounded-full shadow-lg hover:bg-primary/10 animate-pulse"
      onClick={() => window.open('https://medremind.streamlit.app/', '_blank')}
    >
      <MessageCircle className="h-6 w-6" />
    </Button>
  );
}