import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQuery } from "@tanstack/react-query";
import { format, subDays } from "date-fns";
import { Check, X, Calendar, Loader2 } from "lucide-react";
import type { Adherence, Medication } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { useState } from "react";

export default function MedicationHistory() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  // Fetch adherence history for the last 30 days
  const startDate = format(subDays(new Date(), 30), 'yyyy-MM-dd');
  const endDate = format(new Date(), 'yyyy-MM-dd');

  const { data: adherenceHistory = [], isLoading: isLoadingAdherence } = useQuery<Adherence[]>({
    queryKey: ["/api/adherence", { startDate, endDate }]
  });

  const { data: medications = [], isLoading: isLoadingMeds } = useQuery<Medication[]>({
    queryKey: ["/api/medications"]
  });

  // Get medication names for display
  const getMedicationName = (medicationId: number) => {
    const medication = medications.find(med => med.id === medicationId);
    return medication?.name || 'Unknown Medication';
  };

  // Group adherence records by date
  const adherenceByDate = adherenceHistory.reduce((acc, record) => {
    const date = format(new Date(record.scheduledTime), 'yyyy-MM-dd');
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(record);
    return acc;
  }, {} as Record<string, Adherence[]>);

  // Get adherence data for selected date
  const selectedDateHistory = adherenceByDate[format(selectedDate, 'yyyy-MM-dd')] || [];

  // Calculate adherence statistics
  const totalRecords = adherenceHistory.length;
  const takenRecords = adherenceHistory.filter(r => r.taken).length;
  const adherenceRate = totalRecords > 0 ? (takenRecords / totalRecords * 100).toFixed(1) : '0';

  if (isLoadingAdherence || isLoadingMeds) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-xl">Medication History</CardTitle>
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-muted-foreground" />
          <span className="font-semibold">{adherenceRate}% Adherence</span>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="list" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          </TabsList>

          <TabsContent value="list">
            <ScrollArea className="h-[400px] pr-4">
              {Object.entries(adherenceByDate).length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  No medication history available for the last 30 days.
                </p>
              ) : (
                Object.entries(adherenceByDate).reverse().map(([date, records]) => (
                  <div key={date} className="mb-6">
                    <h3 className="font-semibold mb-2">
                      {format(new Date(date), 'MMMM d, yyyy')}
                    </h3>
                    <div className="space-y-3">
                      {records.map((record) => (
                        <div
                          key={record.id}
                          className="flex items-center gap-3 p-3 border rounded-lg bg-background"
                        >
                          <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                            record.taken 
                              ? 'bg-green-100 text-green-600' 
                              : 'bg-red-100 text-red-600'
                          }`}>
                            {record.taken ? <Check className="h-5 w-5" /> : <X className="h-5 w-5" />}
                          </div>
                          <div>
                            <p className="font-medium">{getMedicationName(record.medicationId)}</p>
                            <p className="text-sm text-muted-foreground">
                              Scheduled: {format(new Date(record.scheduledTime), 'h:mm a')}
                            </p>
                            {record.taken && record.takenTime && (
                              <p className="text-sm text-green-600">
                                Taken at {format(new Date(record.takenTime), 'h:mm a')}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))
              )}
            </ScrollArea>
          </TabsContent>

          <TabsContent value="calendar">
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <CalendarComponent
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  className="rounded-md border"
                  modifiers={{
                    hasHistory: (date) => {
                      const dateStr = format(date, 'yyyy-MM-dd');
                      return !!adherenceByDate[dateStr];
                    }
                  }}
                  modifiersStyles={{
                    hasHistory: { 
                      backgroundColor: "hsl(var(--primary) / 0.1)",
                      color: "hsl(var(--primary))",
                      fontWeight: "bold" 
                    }
                  }}
                />
              </div>

              <div>
                <h3 className="font-semibold mb-4">
                  {format(selectedDate, 'MMMM d, yyyy')}
                </h3>
                <ScrollArea className="h-[300px]">
                  {selectedDateHistory.length === 0 ? (
                    <p className="text-muted-foreground">No medications recorded for this date.</p>
                  ) : (
                    <div className="space-y-3">
                      {selectedDateHistory.map((record) => (
                        <div
                          key={record.id}
                          className="flex items-center gap-3 p-3 border rounded-lg bg-background"
                        >
                          <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                            record.taken 
                              ? 'bg-green-100 text-green-600' 
                              : 'bg-red-100 text-red-600'
                          }`}>
                            {record.taken ? <Check className="h-5 w-5" /> : <X className="h-5 w-5" />}
                          </div>
                          <div>
                            <p className="font-medium">{getMedicationName(record.medicationId)}</p>
                            <p className="text-sm text-muted-foreground">
                              Scheduled: {format(new Date(record.scheduledTime), 'h:mm a')}
                            </p>
                            {record.taken && record.takenTime && (
                              <p className="text-sm text-green-600">
                                Taken at {format(new Date(record.takenTime), 'h:mm a')}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}