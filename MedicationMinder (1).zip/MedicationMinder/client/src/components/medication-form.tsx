import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMedicationSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";

const COMMON_INSTRUCTIONS = [
  "Take with food",
  "Take on empty stomach",
  "Take with water",
  "Take before bed",
  "Do not take with dairy products",
  "Avoid alcohol",
  "Custom instructions"
];

const FREQUENCY_TIME_SLOTS = {
  'once_daily': 1,
  'twice_daily': 2,
  'three_times_daily': 3,
  'four_times_daily': 4,
  'weekly': 1,
  'as_needed': 1
};

export default function MedicationForm() {
  const { toast } = useToast();
  const today = new Date().toISOString().split('T')[0];

  const form = useForm({
    resolver: zodResolver(insertMedicationSchema),
    defaultValues: {
      timeOfDay: [new Date().toLocaleTimeString('en-US', { hour12: false }).slice(0, 5)],
      startDate: today,
      frequency: 'once_daily'
    }
  });

  // Update time slots when frequency changes
  useEffect(() => {
    const frequency = form.watch('frequency');
    const currentTimes = form.watch('timeOfDay');
    const requiredSlots = FREQUENCY_TIME_SLOTS[frequency as keyof typeof FREQUENCY_TIME_SLOTS];

    if (currentTimes.length !== requiredSlots) {
      const defaultTime = new Date().toLocaleTimeString('en-US', { hour12: false }).slice(0, 5);
      const newTimes = Array(requiredSlots).fill(defaultTime);
      form.setValue('timeOfDay', newTimes);
    }
  }, [form.watch('frequency')]);

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      // Convert each timeOfDay to a full ISO string for proper storage
      const timeSlots = data.timeOfDay.map((time: string) => 
        new Date(`${data.startDate}T${time}`).toISOString()
      );
      const startDate = new Date(data.startDate).toISOString();
      const endDate = data.endDate ? new Date(data.endDate).toISOString() : null;

      const formattedData = {
        ...data,
        timeOfDay: timeSlots,
        startDate,
        endDate,
      };

      const res = await apiRequest("POST", "/api/medications", formattedData);
      return res.json();
    },
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/medications"] });

      // Show appropriate toast based on reminder status
      if (response.reminder === 'sent') {
        toast({
          title: "Success",
          description: "Medication added successfully with SMS reminders enabled",
        });
      } else if (response.reminder === 'failed') {
        toast({
          title: "Partial Success",
          description: "Medication added but SMS reminders failed. This usually means the Twilio phone number is not properly configured. Please ensure you're using a valid Twilio number, not a personal phone number.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Success",
          description: "Medication added successfully (no SMS reminders configured)",
        });
      }

      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Medication</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Medication Name</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="dosage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Dosage</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="e.g. 10mg" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="frequency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Frequency</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="once_daily">Once Daily</SelectItem>
                        <SelectItem value="twice_daily">Twice Daily</SelectItem>
                        <SelectItem value="three_times_daily">Three Times Daily</SelectItem>
                        <SelectItem value="four_times_daily">Four Times Daily</SelectItem>
                        <SelectItem value="as_needed">As Needed</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {form.watch('timeOfDay')?.map((_, index) => (
              <FormField
                key={index}
                control={form.control}
                name={`timeOfDay.${index}`}
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time of Day {form.watch('timeOfDay').length > 1 ? `#${index + 1}` : ''}</FormLabel>
                    <FormControl>
                      <Input
                        type="time"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            ))}

            <FormField
              control={form.control}
              name="startDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Start Date</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      min={today}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="endDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>End Date (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      min={today}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="instructions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Instructions</FormLabel>
                  <FormControl>
                    <Select
                      onValueChange={(value) => {
                        if (value === "custom") {
                          field.onChange("");
                          return;
                        }
                        field.onChange(value);
                      }}
                      defaultValue={field.value}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select instructions" />
                      </SelectTrigger>
                      <SelectContent>
                        {COMMON_INSTRUCTIONS.map((instruction) => (
                          <SelectItem
                            key={instruction}
                            value={instruction === "Custom instructions" ? "custom" : instruction}
                          >
                            {instruction}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  {field.value === "custom" && (
                    <Input
                      placeholder="Enter custom instructions"
                      onChange={(e) => field.onChange(e.target.value)}
                      className="mt-2"
                    />
                  )}
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full">Add Medication</Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}