import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Phone, AlertTriangle, Heart } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { EmergencyContact } from "@shared/schema";

const EMERGENCY_NUMBERS = {
  EMERGENCY: '108', // Indian Emergency Services
  SUICIDE_PREVENTION: '988', // National Suicide Prevention Lifeline
  POISON_CONTROL: '1-800-222-1222', // National Poison Control Center
  CRISIS_TEXT: '741741', // Crisis Text Line
};

export function EmergencySOS() {
  const [isSOSActive, setIsSOSActive] = useState(false);
  const { toast } = useToast();

  const { data: contacts = [] } = useQuery<EmergencyContact[]>({
    queryKey: ["/api/emergency-contacts"],
  });

  const emergencyServicesMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/sos/trigger", {});
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Emergency Help",
        description: "Stay calm. Emergency contacts are being notified. Call emergency services if immediate help is needed.",
        duration: 10000,
      });
      setIsSOSActive(true);
    },
    onError: () => {
      // Silently handle the error but still show emergency options
      setIsSOSActive(true);
    },
  });

  const handleSOS = () => {
    if (window.confirm("Are you sure you want to trigger Emergency SOS?")) {
      emergencyServicesMutation.mutate();
    }
  };

  return (
    <>
      <Dialog>
        <DialogTrigger asChild>
          <Button 
            variant="destructive" 
            size="lg"
            className="fixed bottom-20 right-4 h-16 w-16 rounded-full shadow-lg z-50 animate-pulse"
          >
            <AlertTriangle className="h-8 w-8" />
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center">Emergency Help</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {/* Emergency Numbers */}
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="text-lg">Emergency Numbers</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>Emergency Services</span>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => window.location.href = `tel:${EMERGENCY_NUMBERS.EMERGENCY}`}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    {EMERGENCY_NUMBERS.EMERGENCY}
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <span>Crisis Helpline</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.location.href = `tel:${EMERGENCY_NUMBERS.SUICIDE_PREVENTION}`}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    {EMERGENCY_NUMBERS.SUICIDE_PREVENTION}
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <span>Poison Control</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.location.href = `tel:${EMERGENCY_NUMBERS.POISON_CONTROL}`}
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    {EMERGENCY_NUMBERS.POISON_CONTROL}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Button
              variant="destructive"
              size="lg"
              className="h-20"
              onClick={handleSOS}
              disabled={isSOSActive}
            >
              {isSOSActive ? (
                "Emergency Contacts Being Notified"
              ) : (
                <>
                  <AlertTriangle className="mr-2 h-6 w-6" />
                  Notify Emergency Contacts
                </>
              )}
            </Button>

            {/* Emergency Contacts */}
            {contacts.length > 0 && (
              <div className="grid gap-2">
                <h3 className="font-semibold">Your Emergency Contacts</h3>
                {contacts.map((contact) => (
                  <Card key={contact.id}>
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Heart className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold">{contact.name}</p>
                          <p className="text-sm text-muted-foreground">{contact.relationship}</p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => window.location.href = `tel:${contact.phone}`}
                      >
                        <Phone className="h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            <div className="text-center text-sm text-muted-foreground space-y-1">
              <p className="font-semibold">In an Emergency:</p>
              <p>1. Stay calm</p>
              <p>2. Call emergency services if needed</p>
              <p>3. Find a safe location if possible</p>
              <p>4. Have your medication list ready</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}