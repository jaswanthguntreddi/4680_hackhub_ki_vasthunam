import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { useState } from "react";
import type { Adherence } from "@shared/schema";
import { MedicationListItem } from "@/components/medication-list-item";

export default function HistoryPage() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  const { data: adherenceHistory = [] } = useQuery<Adherence[]>({
    queryKey: ["/api/adherence", {
      startDate: format(new Date().setDate(new Date().getDate() - 30), 'yyyy-MM-dd'),
      endDate: format(new Date(), 'yyyy-MM-dd')
    }]
  });

  const selectedDateHistory = adherenceHistory.filter(record => 
    format(new Date(record.scheduledTime), 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd')
  );

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Medication History</h1>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Calendar</CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              className="rounded-md border"
              modifiers={{
                hasHistory: (date) => {
                  const dateStr = format(date, 'yyyy-MM-dd');
                  return adherenceHistory.some(record => 
                    format(new Date(record.scheduledTime), 'yyyy-MM-dd') === dateStr
                  );
                }
              }}
              modifiersStyles={{
                hasHistory: { 
                  backgroundColor: "hsl(var(--primary) / 0.1)",
                  color: "hsl(var(--primary))",
                  fontWeight: "bold" 
                }
              }}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>
              Medications for {format(selectedDate, 'MMMM d, yyyy')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDateHistory.length === 0 ? (
              <p className="text-muted-foreground">No medications scheduled for this date.</p>
            ) : (
              <div className="space-y-4">
                {selectedDateHistory.map((record) => (
                  <MedicationListItem
                    key={record.id}
                    medication={{
                      id: record.medicationId,
                      userId: record.userId,
                      name: 'Medication',
                      dosage: '',
                      frequency: '',
                      timeOfDay: record.scheduledTime,
                      startDate: new Date(),
                      endDate: null,
                      instructions: null
                    }}
                    showActions={false}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}