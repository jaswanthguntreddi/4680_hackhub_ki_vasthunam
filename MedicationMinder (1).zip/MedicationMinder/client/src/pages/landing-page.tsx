import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Shield, Bell, Calendar, Activity } from "lucide-react";

export default function LandingPage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Take Control of Your Medication Schedule
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Smart medication tracking with reminders, adherence monitoring, and comprehensive health insights.
          </p>
          {!user && (
            <div className="flex gap-4 justify-center">
              <Link href="/auth">
                <Button size="lg">Get Started</Button>
              </Link>
              <Link href="/auth">
                <Button variant="outline" size="lg">Learn More</Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-background p-6 rounded-lg text-center">
              <Bell className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">Smart Reminders</h3>
              <p className="text-muted-foreground">Never miss a dose with personalized SMS notifications</p>
            </div>
            <div className="bg-background p-6 rounded-lg text-center">
              <Activity className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">Health Tracking</h3>
              <p className="text-muted-foreground">Monitor your medication adherence with detailed insights</p>
            </div>
            <div className="bg-background p-6 rounded-lg text-center">
              <Calendar className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">Schedule Management</h3>
              <p className="text-muted-foreground">Easily manage complex medication schedules</p>
            </div>
            <div className="bg-background p-6 rounded-lg text-center">
              <Shield className="h-12 w-12 mx-auto mb-4 text-primary" />
              <h3 className="text-xl font-semibold mb-2">Secure & Private</h3>
              <p className="text-muted-foreground">Your health data is encrypted and protected</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of users who trust MedTracker for their medication management needs.
          </p>
          {!user && (
            <Link href="/auth">
              <Button size="lg">Create Your Account</Button>
            </Link>
          )}
        </div>
      </section>
    </div>
  );
}
