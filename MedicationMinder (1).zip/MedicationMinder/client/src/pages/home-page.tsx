import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import MedicationForm from "@/components/medication-form";
import AdherenceChart from "@/components/adherence-chart";
import MedicationHistory from "@/components/medication-history";
import { MedicationListItem } from "@/components/medication-list-item";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Clock, Calendar, CheckCircle2, Pill, Activity, Star } from "lucide-react";
import type { Medication } from "@shared/schema";

export default function HomePage() {
  const { user } = useAuth();
  const { data: medications = [], isLoading } = useQuery<Medication[]>({
    queryKey: ["/api/medications"]
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="space-y-8">
        <div className="flex items-center space-x-4">
          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
            <Star className="h-6 w-6 text-primary animate-pulse" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Welcome, {user?.name || user?.username}
          </h1>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-6 grid-cols-1 sm:grid-cols-3">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Medications</CardTitle>
              <Pill className="h-5 w-5 text-primary animate-pulse" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{medications.length}</div>
              <p className="text-xs text-muted-foreground">Active prescriptions</p>
            </CardContent>
          </Card>
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Doses</CardTitle>
              <Clock className="h-5 w-5 text-primary animate-pulse" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">
                {medications.reduce((total, med) => total + (Array.isArray(med.timeOfDay) ? med.timeOfDay.length : 1), 0)}
              </div>
              <p className="text-xs text-muted-foreground">Scheduled for today</p>
            </CardContent>
          </Card>
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Adherence Rate</CardTitle>
              <Activity className="h-5 w-5 text-primary animate-pulse" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">95%</div>
              <p className="text-xs text-muted-foreground">Last 30 days</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left Column - Adherence Chart */}
          <div className="lg:col-span-2">
            <AdherenceChart />
          </div>

          {/* Right Column - Add Medication Form */}
          <div>
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Pill className="h-5 w-5 text-primary" />
                  <CardTitle>Add New Medication</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <MedicationForm />
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Today's Medications */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-primary" />
              <CardTitle>Today's Medications</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] pr-4">
              {medications.length === 0 ? (
                <div className="text-center py-8">
                  <Pill className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No medications added yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {medications.map((med) => (
                    <MedicationListItem key={med.id} medication={med} />
                  ))}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Medication History with Enhanced Visualization */}
        <MedicationHistory />
      </div>
    </div>
  );
}