import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MedicationForm from "@/components/medication-form";
import AdherenceChart from "@/components/adherence-chart";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Bell,
  Calendar,
  Clock,
  Pill,
  Settings,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Plus
} from "lucide-react";
import { format, isToday, parseISO } from "date-fns";
import type { Medication } from "@shared/schema";

export default function DashboardPage() {
  const { user } = useAuth();
  const { data: medications = [], isLoading } = useQuery<Medication[]>({
    queryKey: ["/api/medications"]
  });

  const todaysMedications = medications.filter((med) => {
    const medicationTime = parseISO(med.timeOfDay);
    return isToday(medicationTime);
  });

  const upcomingMedications = medications.filter((med) => {
    const medicationTime = parseISO(med.timeOfDay);
    return !isToday(medicationTime);
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <div className="fixed inset-y-0 left-0 w-64 bg-sidebar border-r">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-sidebar-foreground">MedTracker</h2>
          <div className="mt-6 flex items-center gap-3">
            <Avatar>
              <AvatarFallback>{user?.name?.[0]}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-sidebar-foreground">{user?.name}</p>
              <p className="text-sm text-sidebar-foreground/60">{user?.email}</p>
            </div>
          </div>
        </div>
        <nav className="mt-6">
          <Button variant="ghost" className="w-full justify-start px-6 py-3">
            <Pill className="mr-3 h-5 w-5" />
            Medications
          </Button>
          <Button variant="ghost" className="w-full justify-start px-6 py-3">
            <Bell className="mr-3 h-5 w-5" />
            Reminders
          </Button>
          <Button variant="ghost" className="w-full justify-start px-6 py-3">
            <Calendar className="mr-3 h-5 w-5" />
            Schedule
          </Button>
          <Button variant="ghost" className="w-full justify-start px-6 py-3">
            <Settings className="mr-3 h-5 w-5" />
            Settings
          </Button>
        </nav>
      </div>

      {/* Main Content */}
      <div className="ml-64 p-8">
        <div className="grid gap-6">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Medication
            </Button>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Medications</CardTitle>
                <Pill className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{medications.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Today's Schedule</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{todaysMedications.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Adherence Rate</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">95%</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="col-span-2 md:col-span-1">
              <CardHeader>
                <CardTitle>Today's Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px] pr-4">
                  {todaysMedications.length === 0 ? (
                    <p className="text-muted-foreground">No medications scheduled for today.</p>
                  ) : (
                    <div className="space-y-4">
                      {todaysMedications.map((med) => (
                        <div
                          key={med.id}
                          className="flex items-center justify-between p-4 border rounded-lg"
                        >
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                              <Pill className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-semibold">{med.name}</h3>
                              <p className="text-sm text-muted-foreground">
                                {med.dosage} - {format(parseISO(med.timeOfDay), "hh:mm a")}
                              </p>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            Mark as Taken
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>

            <Card className="col-span-2 md:col-span-1">
              <CardHeader>
                <CardTitle>Adherence Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <AdherenceChart />
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>All Medications</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[300px] pr-4">
                <div className="space-y-4">
                  {medications.map((med) => (
                    <div
                      key={med.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Pill className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{med.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {med.dosage} - {med.frequency}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {format(parseISO(med.timeOfDay), "hh:mm a")}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                        <Button variant="destructive" size="sm">
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}