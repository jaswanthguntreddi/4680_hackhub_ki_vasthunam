import MedicationForm from "@/components/medication-form";

export default function AddMedicationPage() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Add New Medication</h1>
      <div className="max-w-2xl mx-auto">
        <MedicationForm />
      </div>
    </div>
  );
}
