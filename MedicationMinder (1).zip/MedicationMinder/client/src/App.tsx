import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { NavBar } from "@/components/nav-bar";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import LandingPage from "@/pages/landing-page";
import DashboardPage from "@/pages/dashboard";
import AddMedicationPage from "@/pages/add-medication";
import HistoryPage from "@/pages/history";
import { ChatBot } from "@/components/chat-bot";
import { EmergencySOS } from "@/components/emergency-sos";

function Router() {
  return (
    <>
      <NavBar />
      <Switch>
        <Route path="/" component={LandingPage} />
        <Route path="/auth" component={AuthPage} />
        <ProtectedRoute path="/dashboard" component={DashboardPage} />
        <ProtectedRoute path="/add" component={AddMedicationPage} />
        <ProtectedRoute path="/history" component={HistoryPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
        <ChatBot />
        <EmergencySOS />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;