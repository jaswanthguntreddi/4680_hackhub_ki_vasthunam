import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  phone: text("phone"),
  email: text("email"),
  name: text("name"),
});

export const medications = pgTable("medications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(),
  timeOfDay: timestamp("time_of_day").notNull().array(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  instructions: text("instructions"),
});

export const adherence = pgTable("adherence", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  medicationId: integer("medication_id").notNull(),
  taken: boolean("taken").notNull(),
  scheduledTime: timestamp("scheduled_time").notNull(),
  takenTime: timestamp("taken_time"),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  medicationId: integer("medication_id").notNull(),
  message: text("message").notNull(),
  scheduledTime: timestamp("scheduled_time").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  relationship: text("relationship").notNull(),
  isPrimaryContact: boolean("is_primary_contact").notNull().default(false),
});

export const insertUserSchema = createInsertSchema(users)
  .pick({
    username: true,
    password: true,
    phone: true,
    email: true,
    name: true,
  })
  .extend({
    phone: z.string()
      .regex(/^\+[1-9]\d{1,14}$/, 'Phone number must be in international format (e.g. +1234567890)')
      .optional()
      .nullable(),
    email: z.string().email().optional().nullable(),
    name: z.string().min(2, 'Name must be at least 2 characters').optional().nullable(),
  });

export const insertMedicationSchema = createInsertSchema(medications)
  .pick({
    name: true,
    dosage: true,
    frequency: true,
    timeOfDay: true,
    startDate: true,
    endDate: true,
    instructions: true,
  })
  .extend({
    timeOfDay: z.array(z.string()).min(1, "At least one time must be specified"),
    startDate: z.string().refine((date) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return new Date(date) >= today;
    }, "Start date must not be in the past"),
    endDate: z.string().nullable().optional(),
    frequency: z.enum([
      'once_daily',
      'twice_daily',
      'three_times_daily',
      'four_times_daily',
      'as_needed',
      'weekly'
    ]),
  });

export const insertAdherenceSchema = createInsertSchema(adherence).pick({
  medicationId: true,
  taken: true,
  scheduledTime: true,
  takenTime: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  medicationId: true,
  message: true,
  scheduledTime: true,
});

export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts)
  .pick({
    name: true,
    phone: true,
    relationship: true,
    isPrimaryContact: true,
  })
  .extend({
    phone: z.string()
      .regex(/^\+[1-9]\d{1,14}$/, 'Phone number must be in international format (e.g. +1234567890)'),
    relationship: z.string().min(2, 'Relationship must be at least 2 characters'),
  });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertMedication = z.infer<typeof insertMedicationSchema>;
export type InsertAdherence = z.infer<typeof insertAdherenceSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;
export type User = typeof users.$inferSelect;
export type Medication = typeof medications.$inferSelect;
export type Adherence = typeof adherence.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type EmergencyContact = typeof emergencyContacts.$inferSelect;